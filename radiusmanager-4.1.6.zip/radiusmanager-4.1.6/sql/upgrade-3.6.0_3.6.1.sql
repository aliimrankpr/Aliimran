ALTER TABLE `nas` CHANGE `_avpair` `_ciscobwmode` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_actsrv` ADD `datetime` DATETIME NOT NULL AFTER `id` ;
ALTER TABLE `rm_services` ADD `policymapdl` VARCHAR( 50 ) NOT NULL ;
ALTER TABLE `rm_services` ADD `policymapul` VARCHAR( 50 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `unixhost` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `remotehostname` VARCHAR( 100 ) NOT NULL ;
