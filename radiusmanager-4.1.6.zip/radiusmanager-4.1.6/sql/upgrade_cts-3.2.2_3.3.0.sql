DROP TABLE IF EXISTS `conntrack`;
CREATE TABLE `conntrack` (
  `datetime` datetime NOT NULL,
  `username` varchar(64) NOT NULL,
  `srcip` varchar(19) NOT NULL,
  `srcport` int(5) NOT NULL,
  `dstip` varchar(19) NOT NULL,
  `dstport` int(5) NOT NULL,
  `protocol` varchar(3) NOT NULL,
  KEY `datetime` (`datetime`),
  KEY `username` (`username`),
  KEY `srcip` (`srcip`),
  KEY `srcport` (`srcport`),
  KEY `dstip` (`dstip`),
  KEY `dstport` (`dstport`),
  KEY `protocol` (`protocol`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;