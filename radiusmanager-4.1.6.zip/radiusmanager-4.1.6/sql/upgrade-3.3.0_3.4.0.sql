ALTER TABLE `rm_cards` CHANGE `owner` `owner` VARCHAR( 64 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;

ALTER TABLE `rm_changesrv` CHANGE `newsrvname` `newsrvname` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_changesrv` CHANGE `requested` `requested` VARCHAR( 64 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;

ALTER TABLE `rm_ias` CHANGE `iasname` `iasname` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;

ALTER TABLE `rm_invoices` CHANGE `managername` `managername` VARCHAR( 64 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_invoices` CHANGE `service` `service` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_invoices` CHANGE `comment` `comment` VARCHAR( 200 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_invoices` CHANGE `address` `address` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_invoices` CHANGE `city` `city` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_invoices` CHANGE `fullname` `fullname` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_invoices` ADD `deleted` TINYINT( 1 ) NOT NULL ;

ALTER TABLE `rm_managers` CHANGE `managername` `managername` VARCHAR( 64 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_managers` CHANGE `fullname` `firstname` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_managers` ADD `lastname` VARCHAR( 50 ) NOT NULL AFTER `firstname` ;
ALTER TABLE `rm_managers` CHANGE `address` `address` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_managers` CHANGE `city` `city` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_managers` CHANGE `comment` `comment` VARCHAR( 200 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;

ALTER TABLE `rm_payouts` CHANGE `managername` `managername` VARCHAR( 64 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;

ALTER TABLE `rm_services` CHANGE `srvname` `srvname` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_services` CHANGE `poolname` `poolname` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_services` ADD `inittime` INT NOT NULL AFTER `trafficunitcomb` ;
ALTER TABLE `rm_services` ADD `initdl` INT NOT NULL AFTER `inittime` ;
ALTER TABLE `rm_services` ADD `initul` INT NOT NULL AFTER `initdl` ;
ALTER TABLE `rm_services` ADD `inittotal` INT NOT NULL AFTER `initul` ;
ALTER TABLE `rm_services` ADD `minamountadd` INT( 20 ) NOT NULL AFTER `minamount` ;
ALTER TABLE `rm_services` ADD `renew` TINYINT( 1 ) NOT NULL ;

ALTER TABLE `rm_settings` ADD `emailnotify` TINYINT( 1 ) NOT NULL AFTER `emailwarning` ;
ALTER TABLE `rm_settings` CHANGE `exchange` `exchangeusd` DECIMAL( 20, 10 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `exchangegbp` DECIMAL( 20, 10 ) NOT NULL AFTER `exchangeusd` ;

ALTER TABLE `rm_users` CHANGE `firstname` `firstname` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_users` CHANGE `lastname` `lastname` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_users` CHANGE `company` `company` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_users` CHANGE `address` `address` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_users` CHANGE `city` `city` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_users` CHANGE `createdby` `createdby` VARCHAR( 64 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
