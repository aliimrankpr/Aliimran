ALTER TABLE `nas` ADD `_avpair` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `radacct` ADD `_SrvId` INT( 11 ) NOT NULL DEFAULT '-1';
ALTER TABLE `rm_invoices` ADD `phone` VARCHAR( 15 ) NOT NULL ;
ALTER TABLE `rm_invoices` ADD `mobile` VARCHAR( 15 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `pm_internal` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `pm_paypalcc` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `pm_paypalexp` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `pm_netcashcc` TINYINT( 1 ) NOT NULL ;

CREATE TABLE `rm_actsrv` (
  `id` bigint(20) NOT NULL auto_increment,
  `username` varchar(64) NOT NULL,
  `nasip` varchar(15) NOT NULL,
  `nasport` varchar(15) NOT NULL,
  `srvid` int(11) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
