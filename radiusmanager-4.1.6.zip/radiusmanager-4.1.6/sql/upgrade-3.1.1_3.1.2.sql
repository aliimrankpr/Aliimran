# update table 'rm_services'

ALTER TABLE `rm_services` ADD `priority` SMALLINT NOT NULL ;
UPDATE rm_services SET priority = 8 ;
