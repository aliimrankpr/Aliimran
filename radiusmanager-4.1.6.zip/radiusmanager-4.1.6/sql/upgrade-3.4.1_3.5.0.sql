ALTER TABLE `radacct` DROP INDEX `AcctUniqueId` ;
ALTER TABLE `radacct` ADD INDEX ( `AcctUniqueId` ) ;
