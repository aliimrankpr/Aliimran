ALTER TABLE `nas` ENGINE = InnoDB ;

ALTER TABLE `radacct` ADD `_apid` INT NULL ;
ALTER TABLE `radacct` ADD INDEX ( `CallingStationId` ) ;
ALTER TABLE `radacct` ENGINE = InnoDB ;

ALTER TABLE `radcheck` ENGINE = InnoDB ;
ALTER TABLE `radgroupcheck` ENGINE = InnoDB ;
ALTER TABLE `radgroupreply` ENGINE = InnoDB ;

DROP TABLE IF EXISTS `radippool`;
CREATE TABLE `radippool` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `pool_name` varchar(30) character set utf8 NOT NULL,
  `framedipaddress` varchar(15) character set utf8 NOT NULL,
  `nasipaddress` varchar(15) character set utf8 NOT NULL,
  `calledstationid` varchar(30) character set utf8 NOT NULL,
  `callingstationid` varchar(30) character set utf8 NOT NULL,
  `expiry_time` datetime default NULL,
  `username` varchar(64) character set utf8 NOT NULL,
  `pool_key` varchar(30) character set utf8 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

ALTER TABLE `radpostauth` ENGINE = InnoDB ;
ALTER TABLE `radreply` ENGINE = InnoDB ;
ALTER TABLE `radusergroup` ENGINE = InnoDB ;
ALTER TABLE `rm_actsrv` ENGINE = InnoDB ;
ALTER TABLE `rm_allowedmanagers` ENGINE = InnoDB ;
ALTER TABLE `rm_allowednases` ENGINE = InnoDB ;

DROP TABLE IF EXISTS `rm_ap`;
CREATE TABLE `rm_ap` (
  `id` int(11) not null auto_increment,
  `name` varchar(32) not null,
  `enable` tinyint(1) not null,
  `accessmode` tinyint(1) not null,
  `ip` varchar(15) not null,
  `community` varchar(32) not null,
  `apiusername` varchar(32) not null,
  `apipassword` varchar(32) not null,
  `description` varchar(200) not null,
  primary key  (`id`),
  key `ip` (`ip`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

ALTER TABLE `rm_cards` ADD INDEX ( `owner` ) ;
ALTER TABLE `rm_cards` ENGINE = InnoDB ;
ALTER TABLE `rm_changesrv` ENGINE = InnoDB ;

CREATE TABLE `rm_cmts` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(15) NOT NULL,
  `name` varchar(32) NOT NULL,
  `community` varchar(32) NOT NULL,
  `descr` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `ip` (`ip`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

ALTER TABLE `rm_ias` ENGINE = InnoDB ;

ALTER TABLE `rm_invoices` ADD INDEX ( `paid` ) ;
ALTER TABLE `rm_invoices` ENGINE = InnoDB ;

CREATE TABLE `rm_ippools` (
  `id` int(11) NOT NULL auto_increment,
  `type` tinyint(1) not null,
  `name` varchar(32) NOT NULL,
  `fromip` varchar(15) NOT NULL,
  `toip` varchar(15) NOT NULL,
  `descr` varchar(200) NOT NULL,
  `nextpoolid` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`),
  KEY `nextid` (`nextpoolid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

ALTER TABLE `rm_managers` ADD `perm_showinvtotals` TINYINT( 1 ) NOT NULL AFTER `perm_listallinvoices` ;
ALTER TABLE `rm_managers` ADD `perm_enwriteoff` TINYINT( 1 ) NOT NULL AFTER `perm_allowdiscount` ;
ALTER TABLE `rm_managers` ADD `perm_accessap` TINYINT( 1 ) NOT NULL AFTER `perm_enwriteoff` ;
ALTER TABLE `rm_managers` ADD `perm_cts` TINYINT( 1 ) NOT NULL AFTER `perm_accessap` ;
ALTER TABLE `rm_managers` ENGINE = InnoDB ;

DROP TABLE IF EXISTS `rm_onlinecm`;
CREATE TABLE `rm_onlinecm` (
  `username` varchar(64) NOT NULL default '',
  `maccm` varchar(17) default NULL,
  `enableuser` tinyint(1) default NULL,
  `staticipcm` varchar(15) default NULL,
  `ipcpe` varchar(15) default NULL,
  `cmtsid` int(11) default NULL,
  `groupid` int(11) default NULL,
  `groupname` varchar(50) default NULL,
  `snr` decimal(11,1) default NULL,
  `txpwr` decimal(11,1) default NULL,
  `rxpwr` decimal(11,1) default NULL,
  `pingtime` decimal(11,1) default NULL,
  `upstreamname` varchar(50) default NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`username`),
  KEY `maccm` (`maccm`),
  KEY `staticipcm` (`staticipcm`),
  KEY `ipcpe` (`ipcpe`),
  KEY `groupname` (`groupname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `rm_radacct` ENGINE = InnoDB ;

ALTER TABLE `rm_services` ADD `carryover` TINYINT( 1 ) NOT NULL AFTER `renew` ;
ALTER TABLE `rm_services` ADD `gentftp` TINYINT( 1 ) NOT NULL AFTER `custattr` ;
ALTER TABLE `rm_services` ADD `cmcfg` VARCHAR( 1024 ) NOT NULL AFTER `gentftp` ;
ALTER TABLE `rm_services` ADD `advcmcfg` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_services` ADD `addamount` INT NOT NULL ;
ALTER TABLE `rm_services` ADD `ignstatip` TINYINT( 1 ) NOT NULL ;
UPDATE `rm_services` SET addamount =1 ;
UPDATE `rm_services` SET minamountadd =1;
ALTER TABLE `rm_services` ADD INDEX ( `srvname` ) ;
ALTER TABLE `rm_services` ENGINE = InnoDB ;

ALTER TABLE `rm_settings` CHANGE `emailwarning` `emailselfregman` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `emailwelcome` TINYINT( 1 ) NOT NULL AFTER `emailselfregman` ,
ADD `emailnewsrv` TINYINT( 1 ) NOT NULL AFTER `emailwelcome` ,
ADD `emailrenew` TINYINT( 1 ) NOT NULL AFTER `emailnewsrv` ,
ADD `emailexpiry` TINYINT( 1 ) NOT NULL AFTER `emailrenew` ,
ADD `smswelcome` TINYINT( 1 ) NOT NULL AFTER `emailexpiry` ;
ALTER TABLE `rm_settings` DROP `emailnotify` ;
ALTER TABLE `rm_settings` ADD `selfreg_vatid` TINYINT( 1 ) NOT NULL ,
ADD `ias_email` TINYINT( 1 ) NOT NULL ,
ADD `ias_mobile` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_settings` ENGINE = InnoDB ;

ALTER TABLE `rm_specperacnt` ENGINE = InnoDB ;
ALTER TABLE `rm_specperbw` ENGINE = InnoDB ;
ALTER TABLE `rm_syslog` ENGINE = InnoDB ;
ALTER TABLE `rm_usergroups` ENGINE = InnoDB ;

ALTER TABLE `rm_users` CHANGE `comment` `comment` VARCHAR( 500 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
ALTER TABLE `rm_users` CHANGE `staticip` `staticipcpe` VARCHAR( 15 ) NOT NULL ;
ALTER TABLE `rm_users` ADD `staticipcm` VARCHAR( 15 ) NOT NULL AFTER `srvid` ;
ALTER TABLE `rm_users` ADD `ipmodecm` TINYINT( 1 ) NOT NULL AFTER `staticipcpe` ;
ALTER TABLE `rm_users` CHANGE `usestaticip` `ipmodecpe` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_users` ADD `poolidcm` INT NOT NULL AFTER `ipmodecpe` ,
ADD `poolidcpe` INT NOT NULL AFTER `poolidcm` ;
ALTER TABLE `rm_users` DROP INDEX `staticip` ,
ADD INDEX `staticipcpe` ( `staticipcpe` ) ;
UPDATE rm_users SET ipmodecm =1 ;
UPDATE rm_users SET ipmodecpe =2 WHERE ipmodecpe =1 ;
ALTER TABLE `rm_users` ADD `contractid` VARCHAR( 50 ) NOT NULL AFTER `verifymobile` ,
ADD `actcode` VARCHAR( 60 ) NOT NULL AFTER `contractid` ,
ADD `pswactsmsnum` TINYINT( 4 ) NOT NULL AFTER `actcode` ;
ALTER TABLE `rm_users` ADD `gpslat` DECIMAL ( 17, 14 ) NOT NULL AFTER `comment` ,
ADD `gpslong` DECIMAL ( 17, 14 ) NOT NULL AFTER `gpslat` ;
ALTER TABLE `rm_users` ADD INDEX ( `staticipcm` ) ;
ALTER TABLE `rm_users` ADD INDEX ( `expiration` ) ;
ALTER TABLE `rm_users` ADD INDEX ( `createdon` ) ;
ALTER TABLE `rm_users` ADD INDEX ( `contractid` ) ;
ALTER TABLE `rm_users` ENGINE = InnoDB ;

DROP TABLE IF EXISTS `rm_wlan`;
CREATE TABLE `rm_wlan` (
  `maccpe` varchar(17) default NULL,
  `signal` smallint(6) default NULL,
  `ccq` smallint(6) default NULL,
  `snr` smallint(6) default NULL,
  `apip` varchar(15) default NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  KEY `maccpe` (`maccpe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
