ALTER DATABASE radius CHARACTER SET UTF8;

ALTER TABLE nas CONVERT TO CHARACTER SET UTF8;
ALTER TABLE radacct CONVERT TO CHARACTER SET UTF8;
ALTER TABLE radcheck CONVERT TO CHARACTER SET UTF8;
ALTER TABLE radgroupcheck CONVERT TO CHARACTER SET UTF8;
ALTER TABLE radgroupreply CONVERT TO CHARACTER SET UTF8;
ALTER TABLE radpostauth CONVERT TO CHARACTER SET UTF8;
ALTER TABLE radreply CONVERT TO CHARACTER SET UTF8;
ALTER TABLE rm_cards CONVERT TO CHARACTER SET UTF8;
ALTER TABLE rm_changesrv CONVERT TO CHARACTER SET UTF8;
ALTER TABLE rm_invoices CONVERT TO CHARACTER SET UTF8;
ALTER TABLE rm_managers CONVERT TO CHARACTER SET UTF8;
ALTER TABLE rm_payouts CONVERT TO CHARACTER SET UTF8;
ALTER TABLE rm_services CONVERT TO CHARACTER SET UTF8;
ALTER TABLE rm_settings CONVERT TO CHARACTER SET UTF8;
ALTER TABLE rm_users CONVERT TO CHARACTER SET UTF8;
ALTER TABLE usergroup CONVERT TO CHARACTER SET UTF8;

ALTER TABLE `nas` ADD `_password` VARCHAR( 32 ) NOT NULL ;
ALTER TABLE `nas` CHANGE `nasname` `nasname` VARCHAR( 128 ) NOT NULL ;

ALTER TABLE `radacct` DROP INDEX `AcctUniqueId` ;
ALTER ignore TABLE `radacct` ADD UNIQUE ( `AcctUniqueId` );
ALTER TABLE `radacct` CHANGE `NASPortId` `NASPortId` VARCHAR( 15 ) NULL DEFAULT NULL ;
ALTER TABLE `radacct` CHANGE `ConnectInfo_start` `ConnectInfo_start` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ;
ALTER TABLE `radacct` CHANGE `ConnectInfo_stop` `ConnectInfo_stop` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ;
ALTER TABLE `radacct` CHANGE `_AcctTime` `_AcctTime` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00' ;
ALTER TABLE `radacct` CHANGE `AcctInputOctets` `AcctInputOctets` BIGINT( 20 ) NULL DEFAULT NULL ;
ALTER TABLE `radacct` CHANGE `AcctOutputOctets` `AcctOutputOctets` BIGINT( 20 ) NULL DEFAULT NULL ;
ALTER TABLE `radacct` ADD `XAscendSessionSvrKey` VARCHAR( 10 ) DEFAULT NULL AFTER `AcctStopDelay` ;

ALTER TABLE `rm_cards` ADD `comblimit` INT( 11 ) NOT NULL AFTER `uplimit` ;
ALTER TABLE `rm_cards` CHANGE `expiredays` `expiretime` INT( 11 ) NOT NULL ;
ALTER TABLE `rm_cards` ADD `expiretimeunit` SMALLINT( 6 ) NOT NULL ;

ALTER TABLE `rm_services` ADD `limitcomb` TINYINT( 1 ) NOT NULL AFTER `limitul` ;
ALTER TABLE `rm_services` CHANGE `trafficunit` `trafficunitdl` INT( 11 ) NOT NULL ;
ALTER TABLE `rm_services` ADD `trafficunitul` INT( 11 ) NOT NULL AFTER `trafficunitdl` ;
ALTER TABLE `rm_services` ADD `trafficunitcomb` INT( 11 ) NOT NULL AFTER `trafficunitul` ;
ALTER TABLE `rm_services` DROP `timeadd` ;
ALTER TABLE `rm_services` DROP `trafficadd` ;
ALTER TABLE `rm_services` ADD `combquota` BIGINT( 20 ) NOT NULL AFTER `ulquota` ;
ALTER TABLE `rm_settings` ADD `disconnmethod` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `warndl` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `warnul` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `warncomb` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `warnuptime` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `warnexpiry` INT( 11 ) NOT NULL ;
ALTER TABLE `rm_settings` ADD `emailwarning` TINYINT( 1 ) NOT NULL ;
ALTER TABLE `rm_users` ADD `comblimit` BIGINT( 20 ) NOT NULL AFTER `downlimit` ;
ALTER TABLE `rm_users` CHANGE `comment` `comment` VARCHAR( 200 ) NOT NULL ;
ALTER TABLE `rm_users` DROP `macid` ;
ALTER TABLE `rm_users` CHANGE `expiration` `expiration` DATETIME NOT NULL ;
ALTER TABLE `rm_users` ADD `email` VARCHAR( 50 ) NOT NULL AFTER `taxid` ;
ALTER TABLE `rm_users` ADD `warningsent` TINYINT( 1 ) NOT NULL AFTER `maccm` ;
ALTER TABLE `rm_users` DROP `maccpe` ;
ALTER TABLE `rm_users` CHANGE `comment` `comment` VARCHAR( 200 ) NOT NULL ;
ALTER TABLE `rm_users` CHANGE `phone` `phone` VARCHAR( 15 ) NOT NULL ;
ALTER TABLE `rm_users` CHANGE `mobile` `mobile` VARCHAR( 15 ) NOT NULL ;
ALTER TABLE `rm_users` CHANGE `address` `address` VARCHAR( 30 ) NOT NULL ;
ALTER TABLE `rm_users` CHANGE `city` `city` VARCHAR( 15 ) NOT NULL ;
ALTER TABLE `rm_users` CHANGE `zip` `zip` VARCHAR( 8 ) NOT NULL ;
ALTER TABLE `rm_users` CHANGE `staticip` `staticip` VARCHAR( 15 ) NOT NULL ;
ALTER TABLE `rm_users` CHANGE `mac` `mac` VARCHAR( 17 ) NOT NULL ;
UPDATE rm_services SET minamount = 1 WHERE minamount = 0 ;

ALTER TABLE `radgroupreply` DROP `prio` ;

ALTER TABLE `usergroup` ADD `priority` INT( 11 ) NOT NULL ;
ALTER TABLE `usergroup` DROP `id` ;
ALTER TABLE `usergroup` CHANGE `priority` `priority` INT( 11 ) NOT NULL DEFAULT '1' ;

ALTER TABLE `rm_invoices` CHANGE `bytesdown` `bytesdl` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_invoices` CHANGE `bytesup` `bytesul` BIGINT( 20 ) NOT NULL ;
ALTER TABLE `rm_invoices` ADD `bytescomb` BIGINT( 20 ) NOT NULL AFTER `bytesul` ;
ALTER TABLE `rm_invoices` ADD `comblimit` BIGINT( 20 ) NOT NULL AFTER `uplimit` ;
ALTER TABLE `rm_invoices` CHANGE `comment` `comment` VARCHAR( 70 ) NOT NULL ;

ALTER TABLE `rm_managers` CHANGE `phone` `phone` VARCHAR( 15 ) NOT NULL ;
ALTER TABLE `rm_managers` CHANGE `mobile` `mobile` VARCHAR( 15 ) NOT NULL ;
ALTER TABLE `rm_managers` CHANGE `address` `address` VARCHAR( 30 ) NOT NULL ;
ALTER TABLE `rm_managers` CHANGE `city` `city` VARCHAR( 15 ) NOT NULL ;
ALTER TABLE `rm_managers` CHANGE `zip` `zip` VARCHAR( 8 ) NOT NULL ;
ALTER TABLE `rm_managers` CHANGE `comment` `comment` VARCHAR( 50 ) NOT NULL ;
ALTER TABLE `rm_managers` DROP `perm_logout` ;
ALTER TABLE `rm_managers` DROP `perm_listallinvoices` ;
ALTER TABLE `rm_managers` ADD `perm_listallinvoices` TINYINT ( 1 ) NOT NULL AFTER `perm_makepayouts` ;
ALTER TABLE `rm_managers` ADD `perm_logout` TINYINT ( 1 ) NOT NULL AFTER `perm_listallinvoices` ;
ALTER TABLE `rm_invoices` CHANGE `price` `price_old` DECIMAL( 20, 2 ) NOT NULL ;
ALTER TABLE `rm_invoices` ADD `price` DECIMAL( 20, 2 ) NOT NULL AFTER `paid` ;
UPDATE rm_invoices SET price = price_old ;
ALTER TABLE `rm_invoices` DROP `price_old` ;

ALTER TABLE `rm_services` CHANGE `poolname` `poolname` VARCHAR( 25 ) NOT NULL ;
ALTER TABLE `rm_services` CHANGE `minamount` `minamount` INT( 20 ) NOT NULL DEFAULT '1' ;

CREATE TABLE `radippool` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `pool_name` varchar(30) NOT NULL,
  `FramedIPAddress` varchar(15) NOT NULL default '',
  `NASIPAddress` varchar(15) NOT NULL default '',
  `CalledStationId` varchar(30) NOT NULL,
  `CallingStationID` varchar(30) NOT NULL,
  `expiry_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `username` varchar(64) NOT NULL default '',
  `pool_key` varchar(30) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
