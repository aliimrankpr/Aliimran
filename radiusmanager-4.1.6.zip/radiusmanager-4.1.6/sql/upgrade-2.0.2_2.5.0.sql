# modify table 'mt_managers'

ALTER TABLE `mt_managers` CHANGE `password` `password` VARCHAR( 16 ) NOT NULL default '';
ALTER TABLE `mt_managers` CHANGE `realname` `realname` VARCHAR( 30 ) NOT NULL default '';
ALTER TABLE `mt_managers` CHANGE `phone` `phone` VARCHAR( 15 ) NOT NULL default '';
ALTER TABLE `mt_managers` CHANGE `address` `address` VARCHAR( 30 ) NOT NULL default '';
ALTER TABLE `mt_managers` CHANGE `city` `city` VARCHAR( 15 ) NOT NULL default '';
ALTER TABLE `mt_managers` CHANGE `zip` `zip` VARCHAR( 8 ) NOT NULL default '';
ALTER TABLE `mt_managers` CHANGE `comment` `comment` VARCHAR( 50 ) NOT NULL default '';
ALTER TABLE `mt_managers` ADD `mobile` VARCHAR( 15 ) NOT NULL AFTER `phone`;
ALTER TABLE `mt_managers` ADD `perm_listusers` tinyint(1) NULL,
  ADD `perm_createusers` tinyint(1) NULL,
  ADD `perm_editusers` tinyint(1) NULL,
  ADD `perm_deleteusers` tinyint(1) NULL,
  ADD `perm_listmanagers` tinyint(1) NULL,
  ADD `perm_createmanagers` tinyint(1) NULL,
  ADD `perm_editmanagers` tinyint(1) NULL,
  ADD `perm_deletemanagers` tinyint(1) NULL,
  ADD `perm_listprofiles` tinyint(1) NULL,
  ADD `perm_createprofiles` tinyint(1) NULL,
  ADD `perm_editprofiles` tinyint(1) NULL,
  ADD `perm_deleteprofiles` tinyint(1) NULL,
  ADD `perm_listonlineusers` tinyint(1) NULL,
  ADD `perm_listpayments` tinyint(1) NULL,
  ADD `perm_listpayouts` tinyint(1) NULL,
  ADD `perm_searchusers` tinyint(1) NULL,
  ADD `perm_trafficreport` tinyint(1) NULL,
  ADD `perm_addcredits` tinyint(1) NULL,
  ADD `perm_makepayouts` tinyint(1) NULL,
  ADD `perm_listallpayments` tinyint(1) NULL,
  ADD `perm_logout` tinyint(1) NULL;
UPDATE `mt_managers` SET
  `perm_listusers` = '1',
  `perm_createusers` = '1',
  `perm_editusers` = '1',
  `perm_deleteusers` = '1',
  `perm_listmanagers` = '1',
  `perm_createmanagers` = '1',
  `perm_editmanagers` = '1',
  `perm_deletemanagers` = '1',
  `perm_listprofiles` = '1',
  `perm_createprofiles` = '1' ,
  `perm_editprofiles` = '1',
  `perm_deleteprofiles` = '1',
  `perm_listonlineusers` = '1',
  `perm_listpayments` = '1',
  `perm_listpayouts` = '1',
  `perm_searchusers` = '1',
  `perm_trafficreport` = '1',
  `perm_addcredits` = '1',
  `perm_makepayouts` = '1',
  `perm_listallpayments` = '1',
  `perm_logout` = '1'
  WHERE `username` = 'admin';
ALTER TABLE `mt_managers` ADD PRIMARY KEY ( `username` ) ;
  

# modify table 'mt_profiles'

ALTER TABLE `mt_profiles` CHANGE `uprate` `uprate` INT( 11 ) NULL ;
ALTER TABLE `mt_profiles` CHANGE `limitexpiration` `limitexpiration` TINYINT( 1 ) NULL ;
ALTER TABLE `mt_profiles` CHANGE `limituptime` `limituptime` TINYINT( 1 ) NULL ;
ALTER TABLE `mt_profiles` CHANGE `poolname` `poolname` VARCHAR( 25 )  NOT NULL default '';
ALTER TABLE `mt_profiles` CHANGE `downrate` `downrate` INT( 11 ) NULL ;
ALTER TABLE `mt_profiles` CHANGE `limittraffic` `limitdl` TINYINT( 1 ) NULL ;
ALTER TABLE `mt_profiles` CHANGE `profid` `profid` INT( 5 ) NOT NULL ;
ALTER TABLE `mt_profiles` CHANGE `profname` `profname` VARCHAR( 40 ) NOT NULL default '';
ALTER TABLE `mt_profiles` ADD `limitul` TINYINT( 1 ) NULL AFTER `limitdl` ;
ALTER TABLE `mt_profiles` ADD PRIMARY KEY ( `profid` );

# modify table 'mt_users'

ALTER TABLE `mt_users` CHANGE `nomacauth` `usemacauth` TINYINT( 1 ) NULL DEFAULT '0';
ALTER TABLE `mt_users` CHANGE `enableuser` `enableuser` TINYINT( 1 ) NULL ;

ALTER TABLE `mt_users` CHANGE `profid` `profid` TINYINT( 5 ) DEFAULT '0';
ALTER TABLE `mt_users` ADD `staticip` varchar(15) NOT NULL default '',
  ADD `usestaticip` tinyint(1) NULL DEFAULT '0',
  ADD `createdon` date default NULL;
UPDATE mt_users SET usemacauth = '0';
ALTER TABLE `mt_users` CHANGE `uplimit` `uplimit` BIGINT( 20 ) NULL ;
ALTER TABLE `mt_users` CHANGE `downlimit` `downlimit` BIGINT( 20 ) NULL ;
ALTER TABLE `mt_users` CHANGE `realname` `realname` VARCHAR( 30 ) NOT NULL default '';
ALTER TABLE `mt_users` CHANGE `phone` `phone` VARCHAR( 15 ) NOT NULL default '';
ALTER TABLE `mt_users` CHANGE `mobile` `mobile` VARCHAR( 15 ) NOT NULL default '';
ALTER TABLE `mt_users` CHANGE `address` `address` VARCHAR( 30 ) NOT NULL default '';
ALTER TABLE `mt_users` CHANGE `city` `city` VARCHAR( 15 ) NOT NULL default '';
ALTER TABLE `mt_users` CHANGE `zip` `zip` VARCHAR( 8 ) NOT NULL default '';
ALTER TABLE `mt_users` CHANGE `comment` `comment` VARCHAR( 70 ) NOT NULL default '';
ALTER TABLE `mt_users` CHANGE `mac` `mac` VARCHAR( 17 ) NOT NULL default '';
ALTER TABLE `mt_users` CHANGE `macid` `macid` INT( 11 ) NULL ;
ALTER TABLE `mt_users` CHANGE `usemacauth` `usemacauth` TINYINT( 1 ) NULL ;
ALTER TABLE `mt_users` CHANGE `uptimelimit` `uptimelimit` BIGINT( 20 ) NULL ;
ALTER TABLE `mt_users` CHANGE `profid` `profid` TINYINT( 5 ) NULL ;
ALTER TABLE `mt_users` CHANGE `usestaticip` `usestaticip` TINYINT( 1 ) NULL ;
ALTER TABLE `mt_users` CHANGE `password` `password` VARCHAR( 16 ) NOT NULL default '';
ALTER TABLE `mt_users` ADD PRIMARY KEY ( `username` );
ALTER TABLE `mt_users` ADD INDEX ( `profid` );

# modify table 'mt_payments'

ALTER TABLE `mt_payments` CHANGE `profname` `profname` VARCHAR( 40 ) NOT NULL default '';
ALTER TABLE `mt_payments` CHANGE `manager` `manager` VARCHAR( 20 )  NOT NULL default '';
ALTER TABLE `mt_payments` CHANGE `username` `username` VARCHAR( 20 )  NOT NULL default '';
ALTER TABLE `mt_payments` CHANGE `price` `price` DECIMAL( 20, 2 ) NULL ;
ALTER TABLE `mt_payments` CHANGE `bytesdown` `bytesdown` BIGINT( 20 ) NULL ;
ALTER TABLE `mt_payments` CHANGE `bytesup` `bytesup` BIGINT( 20 ) NULL ;
ALTER TABLE `mt_payments` CHANGE `downlimit` `downlimit` BIGINT( 20 ) NULL ;
ALTER TABLE `mt_payments` CHANGE `uplimit` `uplimit` BIGINT( 20 ) NULL ;
ALTER TABLE `mt_payments` CHANGE `hours` `hours` INT( 11 ) NULL ;
ALTER TABLE `mt_payments` CHANGE `uptimelimit` `uptimelimit` BIGINT( 20 ) NULL ;
ALTER TABLE `mt_payments` CHANGE `days` `days` INT( 6 ) NULL ;
ALTER TABLE `mt_payments` CHANGE `comment` `comment` VARCHAR( 70 )  NOT NULL default '';
ALTER TABLE `mt_payments` DROP INDEX `id`;

# modify table 'mt_payouts'

ALTER TABLE `mt_payouts` CHANGE `manager` `manager` VARCHAR( 20 ) NOT NULL default '';
ALTER TABLE `mt_payouts` CHANGE `payout` `payout` DECIMAL( 20, 2 ) NULL ;
