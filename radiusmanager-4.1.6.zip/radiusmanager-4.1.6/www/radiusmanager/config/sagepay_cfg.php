<?php

  // SagePay credentials
  
  define('SAGEPAY_SRVKEY', '33ed960f-4ac4-4c2a-ad61-eee9f1243194');
  define('SAGEPAY_EMAIL',  'info@mycompany.com');

?>
